# import ibeam.config
#
# config.initialize()

__version__ = "0.5.5"
