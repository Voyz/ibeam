import ibeam.config
config.initialize()
