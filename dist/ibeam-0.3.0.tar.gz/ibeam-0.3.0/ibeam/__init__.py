import ibeam.config

config.initialize()

__version__ = "0.3.0"
